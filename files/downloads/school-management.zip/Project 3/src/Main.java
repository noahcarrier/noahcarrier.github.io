import java.io.*;
import java.util.*;


public class Main
{
	public static void main(String[] args)
	{
		String id, option;
		int numStudent = 0, numStaff = 0, numFaculty = 0, numTotal = 0, index;
		int match;

		Student [] student = new Student[100];		//Arrays for separate objects
		Staff [] staff = new Staff[100];
		Faculty [] faculty = new Faculty[100];


		for (int i = 0; i < Person.size; i++)
			Person.people[i] = null;


		System.out.println("\t\t\t\tWelcome to my School Management Program\n\n");

		Menu menu = new Menu();
		Enroll enroll = new Enroll();

		System.out.println("Choose one of the options:");


		while(true)
		{
			Scanner input = new Scanner(System.in);
			menu.mainMenu();
			option = input.nextLine();
			switch(option)
			{
//_________________________________________________________________
      
      
				case "1":   //Enrolling Faculty
					if(numTotal!=100)
					{
						enroll.enrollFaculty(numTotal);
						faculty[numFaculty] = (Faculty)Person.people[numTotal];
						numFaculty++;
						numTotal++;
					}
					if(numTotal==100)
						System.out.println("\n\nNo more available positions");
					break;
//_________________________________________________________________
          
          
		        case "2":	//Enroll students
		          if(numTotal!=100)
		          {
		        	enroll.enrollStudent(numTotal);
		            student[numStudent] = (Student)Person.people[numTotal];
		            numStudent++;
		            numTotal++;
		          }
		          if(numTotal==100)
		            System.out.println("\n\nNo more available positions");
		          break;
//_________________________________________________________________
          
          
		        case "3":	//Print student invoice
		        	System.out.print("Enter the student's ID: ");
		        	id = input.nextLine();
		        	match = 0;
		        	for (int i = 0; i < numTotal; i++)
		        	{
		        		if((Person.people[i].getId().equals(id)))
		        		{	
		        			match = 1;
		        			((Student)Person.people[i]).print();
		        			break;
		        		}	
		        	}
		        	if(match==0)
		        		System.out.println("No Student matched!");
		        	break;
//_________________________________________________________________
        
        
		        case "4":	//Print faculty info
		        	System.out.print("Enter the Faculty's ID: ");
		        	id = input.nextLine();
		        	match = 0;
		        	for (int i = 0; i < numTotal; i++)
		        	{
		        		if((Person.people[i].getId().equals(id)))
		        		{	
		        			match = 1;
		        			((Faculty)Person.people[i]).print();
		        			break;
		        		}	
		        	}
		        	if(match==0)
		        		System.out.println("No Faculty Member matched!");
		        	break;
//_________________________________________________________________
        
        
		        case "5":	//Enroll staff
		          if(numTotal!=100)
		          {
		        	enroll.enrollStaff(numTotal);
		            staff[numStaff] = (Staff)Person.people[numTotal];
		            numStaff++;
		            numTotal++;
		          }
		          if(numTotal==100)
		            System.out.println("\n\nNo more available positions");
		          break;
//_________________________________________________________________
          
          
		        case "6":	//Print staff info
		        	System.out.print("Enter the Staff's ID: ");
		        	id = input.nextLine();
		        	match = 0;
		        	for (int i = 0; i < numTotal; i++)
		        	{
		        		if((Person.people[i].getId().equals(id)))
		        		{	
		        			match = 1;
		        			((Staff)Person.people[i]).print();
		        			break;
		        		}	
		        	}
		        	if(match==0)
		        		System.out.println("No Staff Member matched!");
		        	break;
//_________________________________________________________________
        
        
		        case "7":		//Exiting program & printing report
		        	while(true)
		        	{
		        		System.out.print("\n\n\nWould you like to create the report? (Y/N): ");
		        		option = input.nextLine();
		        		if((option.toLowerCase()).equals("y") ||(option.toLowerCase()).equals("Y"))
		        		{
		        			Report report = new Report();
		        			report.printReport(student, staff, faculty, numStudent, numStaff, numFaculty);        			
		        			System.out.println("Report created and saved on your hard drive!");
		        			break;
		        		}
		        		else if((option.toLowerCase()).equals("n") ||(option.toLowerCase()).equals("N"))
		        			break;
		        		else
		        			System.out.println("\nINVALID INPUT -- TRY AGAIN\n\n");
		        	}
		        	System.out.println("\n\nGoodbye!");
		        	input.close();
		        	System.exit(0);
        
//_________________________________________________________________


        default:																								//Defaulting to invalid input
			System.out.println("\n\nInvalid entry- please try again\n\n");
			continue;
      }
    }
  }
}

final class Faculty extends Employee
{
  private String rank;
//______________________________________ ^ Variables

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}
//______________________________________ ^ Setters and Getters



	public Faculty(String name, String id, String rank, String department) {
		super(name, id, department);
		setRank(rank);
	}
	
	public void print()																					
	{
		System.out.println("\n---------------------------------------------------------------------------");
		System.out.println(super.getName() + "\t\t"+super.getId());
		
		if((super.getDepartment().toLowerCase()).equals("engineering"))
			System.out.print("Engineering Department, ");

		if((super.getDepartment().toLowerCase()).equals("mathematics"))
			System.out.print("Mathematics Department, ");

		if((super.getDepartment().toLowerCase()).equals("english"))
			System.out.print("English Department, ");
		
		if((super.getDepartment().toLowerCase()).equals("sciences"))
			System.out.print("Sciences Department, ");

		if((getRank().toLowerCase()).equals("professor"))
			System.out.print("Professor");
		
		if((getRank().toLowerCase()).equals("adjunct"))
			System.out.print("Adjunct");
		
		System.out.println("\n---------------------------------------------------------------------------");
	}
}

final class Staff extends Employee
{
	private String status;
//______________________________________ ^ Variables
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
//______________________________________ ^ Getters and Setters



	public Staff(String name, String id, String status, String department) {
		super(name, id, department);
		setStatus(status);
	}
	
	public void print()																					//Overwriting abstract print method
	{
		System.out.println("\n---------------------------------------------------------------------------");
		System.out.println(super.getName() + "\t\t"+super.getId());
		
		if((super.getDepartment().toLowerCase()).equals("engineering"))
			System.out.print("Engineering Department, ");

		if((super.getDepartment().toLowerCase()).equals("mathematics"))
			System.out.print("Mathematics Department, ");

		if((super.getDepartment().toLowerCase()).equals("english"))
			System.out.print("English Department, ");

		if((super.getDepartment().toLowerCase()).equals("sciences"))
			System.out.print("Sciences Department, ");

		if((getStatus().toLowerCase()).equals("p"))
			System.out.print("Part Time");
		
		if((getStatus().toLowerCase()).equals("f"))
			System.out.print("Full Time");
		
		System.out.println("\n---------------------------------------------------------------------------");
	}
}

final class Student extends Person
{
	private float gpa;
	private int credits;
//______________________________________ ^ Variables
	public float getGpa()
	{
		return gpa;
	}
	public void setGpa(float gpa)
	{
		this.gpa = gpa;
	}
	public int getCredits()
	{
		return credits;
	}
	public void setCredits(int credits)
	{
		this.credits = credits;
	}
//______________________________________ ^ Getters and Setters
	public Student(String name, String id, float gpa, int credits) {
		super(name, id);
		setGpa(gpa);
		setCredits(credits);
	}
//______________________________________
	public void print()
	{
		double discount;
		double total = (getCredits()*236.45) + 52;													//Calculating tuition based on GPA and credit hours
		if ((getGpa()) >= 3.85) discount=(total*0.25);
		else discount = 0;
		total -= discount;

		System.out.println("\n---------------------------------------------------------------------------");
		System.out.println((super.getName()) + "\t\t"+(super.getId()));
		System.out.println("Credit Hours:"+ (getCredits()) + " ($236.45/credit hour)");
		System.out.println("Fees: $52\n\n");
		System.out.printf("Total payment (after discount): $%,.2f", total);
		System.out.printf("\t($%,.2f discount applied)", discount);
		System.out.println("\n---------------------------------------------------------------------------");
	}
	
}

class Employee extends Person
{
	private String department;
//______________________________________ ^ Variables
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
//______________________________________ ^ Getters and Setters
	public Employee(String name, String id, String department)
	{
		super(name, id);
		setDepartment(department);
	}
	
	
}


class Person
{
	public static int size = 100;
	public static Person [] people = new Person[size];
	private String name, id;

//________________________________
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
//________________________________
	Person(String name, String id) {
		setName(name);
		setId(id);
	}

}


class Enroll
{
	String name, id, rank, department, status;
	float gpa;
	int credits;
	

//_________________________________________________________________
	public void enrollFaculty(int index)
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("\nEnter the faculty info:");

		System.out.print("\tName of Faculty: ");															//Entering name of faculty
		name = input.nextLine();
		
		while(true)
		{
			int idCheck = 0;
			System.out.print("\tID: ");																			//Entering ID of faculty
			id = input.nextLine();
			if (id.length() == 6 && (Character.isLetter((id.charAt(0)))) && (Character.isLetter((id.charAt(1)))) && (Character.isDigit((id.charAt(2)))) && (Character.isDigit((id.charAt(3)))) && (Character.isDigit((id.charAt(4)))) && (Character.isDigit((id.charAt(5)))))
			{	
				for (int i = 0; i < 100; i++)
	        	{
					if(Person.people[i] != null)
					{
						if((Person.people[i].getId().equals(id)))
		        		{	
		        			System.out.println("\n\tID HAS ALREADY BEEN TAKEN, TRY AGAIN\n");
		        			idCheck = 1;
		        		}
					}
	        	}
				if (idCheck == 0)
					break;
				else
					continue;
			}
			else
				System.out.println("\tInvalid ID format. Must be LetterLetterDigitDigitDigitDigit\n");
		}
		while(true)
		{
			System.out.print("\tRank: ");																	//Entering rank of faculty whilst ensuring valid title
			rank = input.nextLine();
			if ((rank.toLowerCase()).equals("professor") || (rank.toLowerCase()).equals("adjunct"))
				break;
			else
				System.out.println("\t\t \""+rank+"\" is invalid");
		}	

		while(true)																							//Entering department of faculty whilst ensuring valid title
		{
			System.out.print("\tDepartment: ");
			department = input.nextLine();
			if ((department.toLowerCase()).equals("mathematics") || (department.toLowerCase()).equals("engineering") || (department.toLowerCase()).equals("english")|| (department.toLowerCase()).equals("sciences"))
				break;
			else
				System.out.println("\t\t \""+department+"\" is invalid");
		}
	
		Person.people[index] = new Faculty(name, id, rank, department);
	}
//_________________________________________________________________
	public void enrollStudent(int index)
	{
		Scanner input = new Scanner(System.in);

		System.out.println("\nEnter the student info:");
		System.out.print("\tName of Student: ");															//Entering name of student
	  	name = input.nextLine();
	  	
	  	while(true)
		{
	  		int idCheck = 0;
			System.out.print("\tID: ");																			//Entering ID of faculty
			id = input.nextLine();
			if (id.length() == 6 && (Character.isLetter((id.charAt(0)))) && (Character.isLetter((id.charAt(1)))) && (Character.isDigit((id.charAt(2)))) && (Character.isDigit((id.charAt(3)))) && (Character.isDigit((id.charAt(4)))) && (Character.isDigit((id.charAt(5)))))
			{
				for (int i = 0; i < 100; i++)
	        	{
					if(Person.people[i] != null)
					{
						if((Person.people[i].getId().equals(id)))
		        		{	
		        			System.out.println("\n\tID HAS ALREADY BEEN TAKEN, TRY AGAIN\n");
		        			idCheck = 1;
		        		}
					}
	        	}
				if (idCheck == 0)
					break;
				else
					continue;
			}
			else
				System.out.println("\tInvalid ID format. Must be LetterLetterDigitDigitDigitDigit\n");
		}
	  	while(true)
	  	{
		  	try {
		  		System.out.print("\tGpa: ");																		//Entering GPA of student
		  		gpa = input.nextFloat();
		  		break;
		  	}
		  	catch (InputMismatchException e)
		  	{
		  		System.out.println("\nAN ERROR HAS OCCURED: INPUT MISMATCH EXCEPTION\n\nPLEASE TRY AGAIN...\n\n");
		  		return;
		  		
		  	}
	  	}
		while(true)
		{
	  		try {
			  	System.out.print("\tCredit hours: ");																//Entering credit hours of student
			  	credits = input.nextInt();
			  	break;
		  	}
		  	catch (InputMismatchException e)
		  	{
		  		System.out.println("\nAN ERROR HAS OCCURED: INPUT MISMATCH EXCEPTION\n\nPLEASE TRY AGAIN...\n\n");
		  		return;
		  	}
		}
		
	  	Person.people[index] = new Student(name, id, gpa, credits);
	}
//_________________________________________________________________
	public void enrollStaff(int index)
	{
		Scanner input = new Scanner(System.in);

		System.out.println("\nEnter the staff info:");
		
		System.out.print("\tName of Staff: ");																//Entering name of staff
		name = input.nextLine();

		while(true)
		{
			int idCheck = 0;
			System.out.print("\tID: ");																			//Entering ID of faculty
			id = input.nextLine();
			if (id.length() == 6 && (Character.isLetter((id.charAt(0)))) && (Character.isLetter((id.charAt(1)))) && (Character.isDigit((id.charAt(2)))) && (Character.isDigit((id.charAt(3)))) && (Character.isDigit((id.charAt(4)))) && (Character.isDigit((id.charAt(5)))))
			{
				for (int i = 0; i < 100; i++)
	        	{
					if(Person.people[i] != null)
					{
						if((Person.people[i].getId().equals(id)))
		        		{	
		        			System.out.println("\n\tID HAS ALREADY BEEN TAKEN, TRY AGAIN\n");
		        			idCheck = 1;
		        		}
					}
	        	}
				if (idCheck == 0)
					break;
				else
					continue;
			}
			else
				System.out.println("\tInvalid ID format. Must be LetterLetterDigitDigitDigitDigit\n");
		}


		while(true)																							//Entering department of staff whilst ensuring valid title
		{
			System.out.print("\tDepartment: ");
			department = input.nextLine();
			if ((department.toLowerCase()).equals("mathematics") || (department.toLowerCase()).equals("engineering") || (department.toLowerCase()).equals("english")|| (department.toLowerCase()).equals("sciences"))
				break;
			else
				System.out.println("\t\t \""+department+"\" is invalid");
		}


		while(true)																							//Entering status of staff whilst ensuring valid title
		{
			System.out.print("\tStatus, Enter P for Part Time, or Enter F for Full Time: ");
			status = input.nextLine();
			if ((status.toLowerCase()).equals("f") || (status.toLowerCase()).equals("p"))
				break;
			else
				System.out.println("\t\t \""+status+"\" is invalid");
		}

    
		Person.people[index] = new Staff(name, id, status, department);
		
	}
}

//Menu Class
class Menu
{
	public void mainMenu()														//Method to print selection menu
	{
		System.out.println("\n\n1- Enter the information of a faculty");
		System.out.println("2- Enter the information of a student");
		System.out.println("3- Print the tuition invoice for a student");
		System.out.println("4- Print faculty information");
		System.out.println("5- Enter the information of a staff member");
		System.out.println("6- Print the information of a staff member");
		System.out.println("7- Exit Program");
		System.out.print("\n\nEnter your selection: ");
	}
}

class Report		//Class to generate report
{
	public void printReport(Student [] student, Staff [] staff, Faculty [] faculty, int numStudent, int numStaff, int numFaculty)
	{
		File report = new File("report.txt");
		
		PrintStream reportOut;
		try {
			reportOut = new PrintStream(report);
			reportOut.println("\tReport created on DATE");
			reportOut.println("\t***********************");
			reportOut.println("\nFaculty Members");
			reportOut.println("-------------------------");
			for(int i = 0; i < numFaculty; i++)
			{
				reportOut.println((i+1)+". "+faculty[i].getName());
				reportOut.println("ID: "+faculty[i].getId());
				reportOut.println(faculty[i].getRank()+", "+faculty[i].getDepartment());
			}
			reportOut.println("\n\nStaff Members");
			reportOut.println("-------------------------");
			for(int i = 0; i < numStaff; i++)
			{
				reportOut.println((i+1)+". "+staff[i].getName());
				reportOut.println("ID: "+staff[i].getId());
				reportOut.println(staff[i].getDepartment()+", "+staff[i].getStatus());
			}
			reportOut.println("\n\nStudents");
			reportOut.println("-------------------------");
			for(int i = 0; i < numStudent; i++)
			{
				reportOut.println((i+1)+". "+student[i].getName());
				reportOut.println("ID: "+student[i].getId());
				reportOut.println("Gpa: "+student[i].getGpa());
				reportOut.println("Credit hours: "+student[i].getCredits() + "\n");
			}
			reportOut.close();
			
		} catch (FileNotFoundException e) {
			System.out.println("\n\nERROR: FILE NOT FOUND EXCEPTION");
			return;
		}
		
	}
	
	
	
}
