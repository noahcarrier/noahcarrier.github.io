filter = [
    {hostContains: "youtube.com"},
    {hostContains: "instagram.com"},
    {hostContains: "twitter.com"},
    {hostContains: "reddit.com"}
];



chrome.webNavigation.onBeforeNavigate.addListener(function (details) {
    
    chrome.storage.sync.get({mode: false}, function(modeDetails) {
        if(modeDetails.mode){
            chrome.storage.sync.get({endSnooze: null}, function(snoozeDetails){

                if(snoozeDetails == null || new Date(snoozeDetails.endSnooze) < new Date()) {
                    chrome.tabs.update(details.tabId, {
                        url: chrome.runtime.getURL("/html/altPage.html")
                    });
                }
            });
        }
    });
}, {url: filter});