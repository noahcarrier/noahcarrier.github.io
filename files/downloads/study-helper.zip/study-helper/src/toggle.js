const toggleButton = document.getElementById('toggleButton');
const modeLabel = document.getElementById('modeLabel');

let studyMode = false;

function clickHandler(){
    studyMode = !studyMode;
    chrome.storage.sync.set({
        mode: studyMode,
    });
    updateLabel();
}

toggleButton.addEventListener("click", function(){
    studyMode = !studyMode;
    chrome.storage.sync.set({
        mode: studyMode
    });
    updateLabel();
});

function updateLabel(){
    modeLabel.textContent = "Study Mode: " + (studyMode ? "ON" : "OFF") + "!";
}


chrome.storage.sync.get({mode: false}, function(result) {
    studyMode = result.mode;
    updateLabel();
});