
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;

class Gui implements ActionListener
{
	private JLabel idJLabel, salaryJLabel, managerJLabel, bonusJLabel, ceoJLabel;
	private JTextField idField, salaryField, bonusField;
	private JRadioButton managerRadioButton, ceoRadioButton;
	private JFrame frame;
	private ButtonGroup bGroup;
	private JButton addButton, resetButton;
	
	
	public Gui()
	{
		addButton = new JButton("ADD");
		resetButton = new JButton("RESET");
		
		addButton.setBounds(50,150,70,20);
		resetButton.setBounds(130,150,70,20);
		
		idJLabel = new JLabel("ID: ");
		salaryJLabel = new JLabel("Salary: ");
		bonusJLabel = new JLabel("Bonus: ");
		managerJLabel = new JLabel("Manager");
		ceoJLabel = new JLabel("CEO");
		
		
		idJLabel.setBounds(50, 50, 70, 20);
		salaryJLabel.setBounds(50, 70, 70, 20);
		bonusJLabel.setBounds(208, 75, 70, 20);
		managerJLabel.setBounds(50, 100, 70, 20);
		ceoJLabel.setBounds(50, 120, 70, 20);
		
		idField = new JTextField(); salaryField = new JTextField(); bonusField = new JTextField();
		
		idField.setBounds(122, 50, 80, 20);
		salaryField.setBounds(122, 75, 80, 20);
		bonusField.setBounds(270, 75, 80, 20);
		
		managerRadioButton = new JRadioButton(); ceoRadioButton = new JRadioButton();
		
		managerRadioButton.setBounds(120, 100, 60, 20);
		ceoRadioButton.setBounds(120, 120, 60, 20);
	
		bGroup = new ButtonGroup();
		bGroup.add(managerRadioButton);
		bGroup.add(ceoRadioButton);
		
		
		frame = new JFrame("Employee Management");
		
		
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,500);
		frame.setLayout(null);
		bonusField.setVisible(false);
		bonusJLabel.setVisible(false);
		
		managerRadioButton.addActionListener(this);
		ceoRadioButton.addActionListener(this);
		resetButton.addActionListener(this);
		addButton.addActionListener(this);
		
		frame.add(idJLabel);
		frame.add(salaryJLabel);
		frame.add(idField);
		frame.add(salaryField);
		frame.add(bonusJLabel);
		frame.add(bonusField);
		frame.add(managerRadioButton);
		frame.add(ceoRadioButton);
		frame.add(managerJLabel);
		frame.add(ceoJLabel);
		frame.add(ceoRadioButton);
		frame.add(addButton);
		frame.add(resetButton);
		
		JLabel idJlabel = new JLabel("ID");
	}
		
	public void actionPerformed (ActionEvent e)
	{
		if(e.getSource() == managerRadioButton)
		{
			bonusJLabel.setVisible(false);
			bonusField.setVisible(false);
		}
		if (e.getSource() == ceoRadioButton)
		{
			bonusJLabel.setVisible(true);
			bonusField.setVisible(true);
		}
		if (e.getSource() == resetButton)
		{
			bonusField.setText("");
			idField.setText("");
			salaryField.setText("");
		}
		if (e.getSource() == addButton)
		{
			String id;
			Double salary, bonus;
				
			salary = Double.parseDouble(salaryField.getText());
			id = idField.getText();
			if(bonusField.isVisible()) { bonus = Double.parseDouble(bonusField.getText()); }
			
			System.out.println("ID: " + id + " SALARY: "+salary);
			
		}
	}
}

public class Main
{
	public static void main(String[] args) {
		
		Gui gui = new Gui();
		
	}
}







//__________________________________________
//CEO Class
final class Ceo extends Manager
{
	private double netWorth;
	
	public void print()
	{
		System.out.println("Inside CEO...");
	}

	public double getNetWorth() {
		return netWorth;
	}

	public void setNetWorth(double netWorth) {
		this.netWorth = netWorth;
	}
	
	
	public String toString()
	{
		return "CEO >>> " + super.toString() + "\t Net Worth: " + netWorth;
	}
	
	public Ceo()
	{
		super("999", 0.0);
		netWorth = 0.0;
	}
	
	public Ceo(String id, double bonus, double netWorth)
	{
		super(id, bonus);
		this.netWorth = netWorth;
	}
}
//__________________________________________








//__________________________________________
//Manager Class
class Manager extends Employee
{
	private double bonus;
	

	public double getBonus()
	{
		return bonus;
	}

	public void setBonus(double bonus)
	{
		this.bonus = bonus;
	}
	
	public String toString()
	{
		return "MANAGER >>> " + super.toString() + "\tBONUS: "+ bonus;
	}
	
	public Manager()
	{
		super();
		bonus = 0.0;
	}
	
	public Manager(String id)
	{
		super(id);
		bonus = 0.0;
	}
	
	public Manager(String id, double bonus)
	{
		super(id);
		this.bonus = bonus;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
//__________________________________________







//__________________________________________
//Employee Class
abstract class Employee
{
	
	private String id;
	
	
	abstract public void print();
	
	
	
	public String getId()
	{
		return id;
	}
	



	public void setId(String id)
	{
		this.id = id;
	}
	
	
	
	public Employee()
	{
		id = "0";
	}
	
	
	
	public Employee(String id)
	{
		this.id = id;
	}
	
	
	
	public String toString()
	{
		return "ID: "+id;
	}
	
	public void doSomething()
	{
		System.out.println("Inside Employee...");
	}
}
//__________________________________________



//__________________________________________


//__________________________________________









